# CG_Lab_Setup
This is the zip file which contains the freeglut packages used for Computer Graohics Lab
